/* Service worker: guarda o app no celular para funcionar sem internet. */
const VERSAO = 'almoxarifado-v1';
const ARQUIVOS = [
  './',
  './index.html',
  './styles.css',
  './app.js',
  './manifest.webmanifest',
  './icon-192.png',
  './icon-512.png',
  './maskable-512.png'
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(VERSAO).then((c) => c.addAll(ARQUIVOS)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then((ks) => Promise.all(ks.filter((k) => k !== VERSAO).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  /* Arquivos do próprio app: primeiro o que está guardado, atualiza em segundo plano. */
  if (url.origin === location.origin) {
    e.respondWith(
      caches.match(req).then((guardado) => {
        const rede = fetch(req).then((r) => {
          if (r && r.ok) { const copia = r.clone(); caches.open(VERSAO).then((c) => c.put(req, copia)); }
          return r;
        }).catch(() => guardado);
        return guardado || rede;
      })
    );
    return;
  }

  /* Fontes e leitor de código de reserva: guarda na primeira vez que carregam. */
  const ehRecurso = /fonts\.googleapis\.com|fonts\.gstatic\.com|cdn\.jsdelivr\.net/.test(url.host);
  if (ehRecurso) {
    e.respondWith(
      caches.match(req).then((guardado) =>
        guardado || fetch(req).then((r) => {
          if (r && (r.ok || r.type === 'opaque')) { const copia = r.clone(); caches.open(VERSAO).then((c) => c.put(req, copia)); }
          return r;
        })
      )
    );
  }
  /* Consultas de produto (Open Facts) passam direto: sem internet, o app pede para digitar. */
});
