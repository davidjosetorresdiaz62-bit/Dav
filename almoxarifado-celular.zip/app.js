(function(){
'use strict';

/* ---------- utilidades ---------- */
var $ = function(s, r){ return (r||document).querySelector(s); };
var $$ = function(s, r){ return Array.prototype.slice.call((r||document).querySelectorAll(s)); };
function esc(s){ return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
function num(v){ var x = Number(v); return isFinite(x) ? x : 0; }
function pl(n, um, varios){ return n + ' ' + (n === 1 ? um : varios); }
function nat(a, b){ return String(a).localeCompare(String(b), 'pt-BR', {numeric:true}); }
function pausa(ms){ return new Promise(function(r){ setTimeout(r, ms); }); }

var P = {
  warehouse:'<path d="M3 21V9l9-5 9 5v12"/><path d="M7 21v-8h10v8"/><path d="M7 17h10"/>',
  alert:'<path d="M12 3 2 20h20L12 3z"/><path d="M12 10v4"/><path d="M12 17.2v.01"/>',
  shelves:'<path d="M4 4h16M4 12h16M4 20h16"/><path d="M6 4v8M18 4v8M6 12v8M18 12v8"/>',
  scan:'<path d="M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3"/><path d="M7 12h10"/>',
  chart:'<path d="M5 20V11M12 20V5M19 20v-7"/>',
  search:'<circle cx="11" cy="11" r="6"/><path d="m20 20-4.5-4.5"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  minus:'<path d="M5 12h14"/>',
  up:'<path d="M12 19V5M6 11l6-6 6 6"/>',
  down:'<path d="M12 5v14M6 13l6 6 6-6"/>',
  bottle:'<path d="M10 3h4v3l2 3v11a1 1 0 0 1-1 1H9a1 1 0 0 1-1-1V9l2-3V3z"/><path d="M8 13h8"/>',
  chev:'<path d="m9 6 6 6-6 6"/>',
  list:'<path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01"/>',
  x:'<path d="M6 6l12 12M18 6 6 18"/>',
  bolt:'<path d="M13 3 5 14h6l-1 7 8-11h-6l1-7z"/>'
};
function ico(n, s){ s = s || 22; return '<svg class="i" width="'+s+'" height="'+s+'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+P[n]+'</svg>'; }

/* ---------- estado e armazenamento (neste aparelho) ---------- */
var S = { tab:'alertas', produtos:[], movs:[], sel:null, busca:'', prat:'*', busy:false };
var LS = 'almoxarifado-v1';
var instalar = null;

function norm(o, id){
  return { id:id || o.id, codigo:String(o.codigo||''), nome:String(o.nome||''), marca:String(o.marca||''),
    prateleira:String(o.prateleira||''), validade:String(o.validade||''), qtd:num(o.qtd),
    min:(o.min == null ? 5 : num(o.min)), exemplo:!!o.exemplo };
}
function salvar(){
  try{ localStorage.setItem(LS, JSON.stringify({ p:S.produtos, m:S.movs.slice(0, 3000) })); return true; }
  catch(e){ setStatus('err', 'Não foi possível guardar no aparelho (memória cheia ou bloqueada). Exporte um backup.'); return false; }
}
function carregar(){
  try{
    var j = JSON.parse(localStorage.getItem(LS) || 'null');
    if(j){ S.produtos = (j.p || []).map(function(o){ return norm(o); }); S.movs = j.m || []; }
  }catch(e){}
}
function putProduto(p){
  var o = norm(p, p.id), i = -1;
  S.produtos.forEach(function(x, k){ if(x.id === p.id) i = k; });
  if(i >= 0) S.produtos[i] = o; else S.produtos.push(o);
  salvar();
}
function addMov(m){
  S.movs.unshift({ id:'m' + m.ts + Math.random().toString(36).slice(2,6), ts:m.ts, tipo:m.tipo, id_produto:m.id_produto, nome:m.nome, qtd:m.qtd, quem:m.quem || '', exemplo:!!m.exemplo });
  S.movs.sort(function(a, b){ return b.ts - a.ts; });
  salvar();
}
function delProduto(id){ S.produtos = S.produtos.filter(function(x){ return x.id !== id; }); salvar(); }
function novoId(code){
  var c = String(code||'').replace(/\s+/g, '');
  if(/^[A-Za-z0-9._~:@+-]{1,60}$/.test(c) && c !== '.' && c !== '..') return c;
  return 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2,5);
}
function achar(code){
  var c = String(code||'').replace(/\s+/g, '');
  if(!c) return null;
  var r = null;
  S.produtos.forEach(function(p){ if(!r && (p.codigo === c || p.id === c)) r = p; });
  return r;
}

/* ---------- datas e estados ---------- */
function hoje(){ var d = new Date(); return new Date(d.getFullYear(), d.getMonth(), d.getDate()); }
function startOfDay(ts){ var d = new Date(ts); return new Date(d.getFullYear(), d.getMonth(), d.getDate()); }
function diasAte(iso){
  if(!/^\d{4}-\d{2}-\d{2}$/.test(iso||'')) return null;
  var p = iso.split('-').map(Number);
  return Math.round((new Date(p[0], p[1]-1, p[2]) - hoje()) / 86400000);
}
function fmtData(iso){ return iso ? iso.split('-').reverse().join('/') : ''; }
function validadeInfo(iso){
  var n = diasAte(iso);
  if(n === null) return null;
  if(n < 0) return { t:'Vencido há ' + pl(-n, 'dia', 'dias'), c:'bad' };
  if(n === 0) return { t:'Vence hoje', c:'bad' };
  if(n <= 60) return { t:'Vence em ' + pl(n, 'dia', 'dias'), c:'warn' };
  var m = Math.round(n / 30.4);
  return { t:'Vence em ' + pl(m, 'mês', 'meses'), c:'ok' };
}
function statusOf(p){
  if(p.qtd <= 0) return { k:'out', t:'Esgotado' };
  if(p.qtd <= p.min) return { k:'low', t:'Estoque baixo' };
  return { k:'ok', t:'Em estoque' };
}

/* ---------- telas ---------- */
function setSync(){
  $('#sync').textContent = navigator.onLine ? 'Salvo neste aparelho' : 'Salvo neste aparelho · sem internet';
}
function rowProd(p, bar){
  var st = statusOf(p), pct = Math.max(0, Math.min(100, Math.round(p.qtd / Math.max(p.min*3, 1) * 100)));
  return '<button type="button" class="row s-'+st.k+'" data-a="abrir" data-id="'+esc(p.id)+'">' +
    '<span class="ic">'+ico('bottle')+'</span>' +
    '<span style="min-width:0"><span class="nm">'+esc(p.nome)+'</span>' +
      (bar ? '<span class="bar" style="display:block"><i style="width:'+pct+'%"></i></span>'
           : '<span class="st" style="display:block">'+esc(st.t)+'</span>') +
      (p.marca && !bar ? '<span class="sm" style="display:block">'+esc(p.marca)+'</span>' : '') +
    '</span>' +
    '<span class="q"><b>'+p.qtd+'</b><span>EM ESTOQUE</span></span>' +
    '<span class="ch">'+ico('chev',18)+'</span></button>';
}
function extrasHtml(){
  return '<div class="extras"><div class="lbl">Backup e instalação</div>' +
    '<div class="actions"><button class="ghost" type="button" data-a="exportar">Exportar backup</button>' +
    '<button class="ghost" type="button" data-a="importar">Importar backup</button></div>' +
    (instalar ? '<button class="ghost" type="button" data-a="instalar">Instalar o app neste aparelho</button>' : '') +
    '<small>Os dados ficam só neste aparelho. Exporte um backup de vez em quando.</small></div>';
}
function renderAlertas(){
  var el = $('#tab-alertas');
  if(!S.produtos.length){
    el.innerHTML = '<div class="card hero"><p class="t">Nenhum produto cadastrado</p>' +
      '<p class="sub">Escaneie o primeiro produto para começar. Cada produto fica salvo, e nas próximas leituras os dados aparecem sozinhos.</p>' +
      '<button class="cta" type="button" data-a="go-escanear" style="margin-top:8px">'+ico('scan')+'Escanear primeiro produto</button>' +
      '<button class="ghost" type="button" data-a="exemplos">Ver com dados de exemplo</button></div>' + extrasHtml();
    return;
  }
  var rep = S.produtos.filter(function(p){ return p.qtd <= p.min; })
    .sort(function(a,b){ return a.qtd - b.qtd || nat(a.nome, b.nome); });
  var out = rep.filter(function(p){ return p.qtd <= 0; }).length, low = rep.length - out;
  var k = out ? 'out' : (low ? 'low' : 'ok');
  var h = '<div class="card hero s-'+k+'"><div class="top-row"><div><div class="lbl">Produtos para repor</div>' +
    '<div class="big">'+rep.length+'</div></div><div class="badge">'+ico('alert',26)+'</div></div>';
  if(rep.length){
    h += '<p class="t">'+(rep.length === 1 ? 'produto para repor' : 'produtos para repor')+'</p>' +
      '<div class="sub">'+pl(out,'esgotado','esgotados')+' · '+pl(low,'baixo','baixos')+'</div>' +
      '<div class="segs">'+rep.map(function(p){ return '<i class="s-'+statusOf(p).k+'"></i>'; }).join('')+'</div>';
  } else {
    h += '<p class="t">Tudo em ordem</p><div class="sub">Nenhum produto abaixo do estoque mínimo.</div><div class="segs"><i></i></div>';
  }
  h += '</div>';
  if(rep.length){
    h += '<div class="list">'+rep.map(function(p){ return rowProd(p, false); }).join('')+'</div>' +
      '<button class="cta" type="button" data-a="pedido">'+ico('list')+'Gerar lista de pedido</button>';
  }
  var venc = S.produtos.filter(function(p){ var n = diasAte(p.validade); return n !== null && n <= 60; })
    .sort(function(a,b){ return diasAte(a.validade) - diasAte(b.validade); });
  if(venc.length){
    h += '<h2 class="lbl">Vencimento próximo</h2><div class="list">' + venc.map(function(p){
      var v = validadeInfo(p.validade);
      return '<button type="button" class="row" data-a="abrir" data-id="'+esc(p.id)+'" style="grid-template-columns:auto minmax(0,1fr) auto">' +
        '<span class="ic">'+ico('bottle')+'</span><span style="min-width:0"><span class="nm">'+esc(p.nome)+'</span>' +
        '<span class="sm" style="display:block">'+(p.prateleira ? 'Prateleira '+esc(p.prateleira)+' · ' : '')+fmtData(p.validade)+'</span></span>' +
        '<span class="pill '+v.c+'">'+esc(v.t)+'</span></button>';
    }).join('') + '</div>';
  }
  if(S.produtos.some(function(p){ return p.exemplo; })){
    h += '<button class="link" type="button" data-a="apagar-exemplos">Apagar dados de exemplo</button>';
  }
  el.innerHTML = h + extrasHtml();
}
function renderEstantes(){
  var chips = $('#chips'), list = $('#lista-est');
  var prats = [];
  S.produtos.forEach(function(p){ if(prats.indexOf(p.prateleira) < 0) prats.push(p.prateleira); });
  prats.sort(function(a,b){ return a === '' ? 1 : (b === '' ? -1 : nat(a,b)); });
  if(S.prat !== '*' && prats.indexOf(S.prat === '__sem' ? '' : S.prat) < 0) S.prat = '*';
  var cs = [{v:'*', t:'Todas'}].concat(prats.map(function(x){ return { v:x === '' ? '__sem' : x, t:x === '' ? 'Sem prateleira' : x }; }));
  chips.innerHTML = cs.map(function(c){
    return '<button type="button" class="chip" data-a="chip" data-v="'+esc(c.v)+'" aria-pressed="'+(S.prat === c.v)+'">'+esc(c.t)+'</button>';
  }).join('');
  var q = S.busca.trim().toLowerCase();
  var fil = S.produtos.filter(function(p){
    if(S.prat !== '*' && (S.prat === '__sem' ? p.prateleira !== '' : p.prateleira !== S.prat)) return false;
    if(!q) return true;
    return (p.nome + ' ' + p.marca + ' ' + p.codigo).toLowerCase().indexOf(q) >= 0;
  });
  if(!S.produtos.length){ list.innerHTML = '<p class="muted pad">Nenhum produto cadastrado. Use a aba Escanear.</p>'; return; }
  if(!fil.length){ list.innerHTML = '<p class="muted pad">Nada encontrado.</p>'; return; }
  var groups = {};
  fil.forEach(function(p){ (groups[p.prateleira] = groups[p.prateleira] || []).push(p); });
  var keys = Object.keys(groups).sort(function(a,b){ return a === '' ? 1 : (b === '' ? -1 : nat(a,b)); });
  list.innerHTML = keys.map(function(k){
    var arr = groups[k].sort(function(a,b){ return nat(a.nome, b.nome); });
    return '<div class="shelf">'+ico('shelves',20)+'<b>'+(k === '' ? 'Sem prateleira' : 'Prateleira '+esc(k))+'</b><span>'+pl(arr.length,'item','itens')+'</span></div>' +
      '<div class="list" style="margin-top:8px">'+arr.map(function(p){ return rowProd(p, true); }).join('')+'</div>';
  }).join('');
}
function renderHistorico(){
  var el = $('#tab-historico');
  var h0 = hoje(), dow = (h0.getDay() + 6) % 7;
  var ini = new Date(h0.getFullYear(), h0.getMonth(), h0.getDate() - dow);
  var sai = [0,0,0,0,0,0,0], tS = 0, tE = 0;
  S.movs.forEach(function(m){
    var i = Math.round((startOfDay(m.ts) - ini) / 86400000);
    if(i >= 0 && i < 7){ if(m.tipo === 'saida'){ sai[i] += num(m.qtd); tS += num(m.qtd); } else { tE += num(m.qtd); } }
  });
  var mx = Math.max.apply(null, sai), nomes = ['Seg','Ter','Qua','Qui','Sex','Sáb','Dom'];
  var h = '<div class="card"><div class="lbl">Consumo semanal</div>' +
    '<div style="font:600 24px var(--fd);margin-top:4px">'+tS+' saídas · '+tE+' entradas</div>' +
    '<div class="chart" role="img" aria-label="Saídas por dia da semana">' + sai.map(function(v){
      var pk = mx > 0 && v === mx;
      return '<div class="c'+(pk ? ' pk' : '')+'"><b>'+v+'</b><i style="height:'+(mx ? Math.round(v/mx*100*0.78) : 0)+'%"></i></div>';
    }).join('') + '</div><div class="days">' + nomes.map(function(n){ return '<span>'+n+'</span>'; }).join('') + '</div></div>';
  if(!S.movs.length){
    h += '<p class="muted pad">Nenhuma movimentação ainda. Registre uma entrada ou saída na aba Escanear.</p>';
    el.innerHTML = h; return;
  }
  var ontem = new Date(h0.getFullYear(), h0.getMonth(), h0.getDate() - 1), ultimo = '';
  S.movs.slice(0, 100).forEach(function(m){
    var key = startOfDay(m.ts).getTime(), lab;
    if(key === h0.getTime()) lab = 'Hoje'; else if(key === ontem.getTime()) lab = 'Ontem';
    else lab = new Date(m.ts).toLocaleDateString('pt-BR', {weekday:'long', day:'numeric', month:'short'});
    if(lab !== ultimo){ h += '<h2 class="lbl">'+esc(lab)+'</h2>'; ultimo = lab; }
    var ent = m.tipo !== 'saida', hora = new Date(m.ts).toLocaleTimeString('pt-BR', {hour:'2-digit', minute:'2-digit'});
    h += '<div class="row mov '+(ent ? 'in' : 'out')+'"><span class="ic">'+ico(ent ? 'up' : 'down', 20)+'</span>' +
      '<span style="min-width:0"><span class="nm">'+(ent ? 'Entrada' : 'Saída')+' · '+esc(m.nome)+'</span>' +
      '<span class="sm" style="display:block">'+(m.quem ? esc(m.quem)+' · ' : '')+hora+'</span></span>' +
      '<span class="n">'+(ent ? '+' : '−')+num(m.qtd)+'</span></div>';
  });
  el.innerHTML = h;
}
function renderAll(){ setSync(); renderAlertas(); renderEstantes(); renderHistorico(); refreshScan(); }

function go(tab){
  S.tab = tab;
  ['alertas','prateleiras','escanear','historico'].forEach(function(t){ $('#tab-'+t).hidden = (t !== tab); });
  $$('.tabs button').forEach(function(b){ if(b.dataset.tab === tab) b.setAttribute('aria-current','page'); else b.removeAttribute('aria-current'); });
  $('#main').scrollTop = 0;
}

/* ---------- formulário de escaneamento ---------- */
function setStatus(kind, msg){
  var el = $('#status');
  if(!msg){ el.hidden = true; el.textContent = ''; return; }
  el.hidden = false; el.className = 'status ' + (kind || ''); el.textContent = msg;
}
function lerForm(){
  return { codigo:$('#f-codigo').value.replace(/\s+/g,''), nome:$('#f-nome').value.trim(), marca:$('#f-marca').value.trim(),
    prateleira:$('#f-prat').value.trim(), validade:$('#f-val').value, min:Math.max(0, parseInt($('#f-min').value, 10) || 0),
    qtd:Math.max(1, parseInt($('#f-qtd').value, 10) || 1), quem:$('#f-quem').value.trim() };
}
function updValPill(){
  var v = validadeInfo($('#f-val').value), el = $('#val-pill');
  if(!v){ el.hidden = true; return; }
  el.hidden = false; el.className = 'pill ' + v.c; el.textContent = v.t;
}
function fillForm(p){
  $('#f-codigo').value = p ? p.codigo : '';
  $('#f-nome').value = p ? p.nome : '';
  $('#f-marca').value = p ? p.marca : '';
  $('#f-prat').value = p ? p.prateleira : '';
  $('#f-val').value = p ? p.validade : '';
  $('#f-min').value = p ? p.min : 5;
  $('#f-qtd').value = 1;
  updValPill(); refreshScan();
}
function refreshScan(){
  var dl = $('#prats'), seen = [];
  S.produtos.forEach(function(p){ if(p.prateleira && seen.indexOf(p.prateleira) < 0) seen.push(p.prateleira); });
  seen.sort(nat);
  dl.innerHTML = seen.map(function(x){ return '<option value="'+esc(x)+'"></option>'; }).join('');
  var p = null;
  if(S.sel){ S.produtos.forEach(function(x){ if(x.id === S.sel) p = x; }); if(!p) S.sel = null; }
  var box = $('#info');
  if(!p){ box.hidden = true; $('#btn-del').hidden = true; return; }
  var st = statusOf(p);
  box.hidden = false; box.className = 'info s-' + st.k;
  box.innerHTML = '<span>No estoque agora</span><b>'+p.qtd+'</b><span class="tag">'+esc(st.t.toUpperCase())+'</span>';
  $('#btn-del').hidden = false;
}
function selecionar(p){ S.sel = p.id; fillForm(p); }
function limpar(){ S.sel = null; fillForm(null); }
function abrirProduto(id){
  var p = null; S.produtos.forEach(function(x){ if(x.id === id) p = x; });
  if(!p) return;
  selecionar(p); setStatus('', ''); go('escanear');
}

/* ---------- consulta pública de produtos (precisa de internet) ---------- */
async function buscarOnline(code){
  var bases = ['openproductsfacts', 'openfoodfacts', 'openbeautyfacts'];
  for(var i = 0; i < bases.length; i++){
    try{
      var ctl = new AbortController(), t = setTimeout(function(){ ctl.abort(); }, 6000);
      var r = await fetch('https://world.' + bases[i] + '.org/api/v2/product/' + encodeURIComponent(code) + '.json?fields=product_name,product_name_pt,brands,quantity', { signal:ctl.signal });
      clearTimeout(t);
      if(!r.ok) continue;
      var j = await r.json();
      if(j && j.status === 1 && j.product){
        var nome = String(j.product.product_name_pt || j.product.product_name || '').trim();
        if(!nome) continue;
        var q = String(j.product.quantity || '').trim();
        if(q && nome.toLowerCase().indexOf(q.toLowerCase()) < 0) nome += ' ' + q;
        var marca = String(j.product.brands || '').split(',')[0].trim();
        return { nome:nome, marca:marca };
      }
    }catch(e){}
  }
  return null;
}
async function aoLerCodigo(code){
  code = String(code || '').replace(/\s+/g, '');
  if(!code) return;
  go('escanear');
  var p = achar(code);
  if(p){ selecionar(p); setStatus('ok', 'Produto encontrado no estoque: ' + p.nome + '.'); return; }
  S.sel = null; fillForm(null); $('#f-codigo').value = code; refreshScan();
  if(!navigator.onLine){
    setStatus('warn', 'Código ' + code + ' lido. Sem internet: preencha o nome e a validade. Na próxima vez o produto aparece sozinho.');
    return;
  }
  setStatus('busy', 'Código ' + code + ' lido. Procurando o produto na internet…');
  var r = await buscarOnline(code);
  if($('#f-codigo').value.replace(/\s+/g,'') !== code) return; /* a pessoa já mudou de produto */
  if(r){
    $('#f-nome').value = r.nome; $('#f-marca').value = r.marca;
    setStatus('ok', 'Dados achados na base pública. Confira o nome e informe a validade.');
  } else {
    setStatus('warn', 'Código ' + code + ' lido, mas não está na base pública. Preencha o nome e a validade uma vez; na próxima vez aparece sozinho.');
    $('#f-nome').focus();
  }
}
function buscarCodigo(){
  var c = $('#f-codigo').value.replace(/\s+/g,'');
  if(!c){ setStatus('warn', 'Digite ou escaneie um código de barras.'); return; }
  aoLerCodigo(c);
}

/* ---------- leitor de código (câmera ao vivo) ---------- */
var scan = { stream:null, timer:0, ativo:false, det:null, zx:null, lanterna:false };
var FORMATOS = ['ean_13','ean_8','upc_a','upc_e','code_128','code_39','itf','codabar'];

function carregarZXing(){
  return new Promise(function(ok, falha){
    if(window.ZXing) return ok(window.ZXing);
    var s = document.createElement('script');
    s.src = 'https://cdn.jsdelivr.net/npm/@zxing/library@0.21.3/umd/index.min.js';
    s.onload = function(){ window.ZXing ? ok(window.ZXing) : falha(new Error('zxing')); };
    s.onerror = function(){ falha(new Error('zxing')); };
    document.head.appendChild(s);
  });
}
async function criarLeitor(){
  /* Primeiro o leitor do próprio Chrome; se não existir, o leitor de reserva. */
  if('BarcodeDetector' in window){
    try{
      var sup = await BarcodeDetector.getSupportedFormats();
      var fm = FORMATOS.filter(function(f){ return sup.indexOf(f) >= 0; });
      var det = new BarcodeDetector(fm.length ? { formats:fm } : undefined);
      return function(fonte){ return det.detect(fonte).then(function(r){ return r.length ? String(r[0].rawValue) : ''; }); };
    }catch(e){}
  }
  var Z = await carregarZXing();
  var hints = new Map();
  hints.set(Z.DecodeHintType.POSSIBLE_FORMATS, [Z.BarcodeFormat.EAN_13, Z.BarcodeFormat.EAN_8, Z.BarcodeFormat.UPC_A, Z.BarcodeFormat.UPC_E, Z.BarcodeFormat.CODE_128, Z.BarcodeFormat.CODE_39, Z.BarcodeFormat.ITF, Z.BarcodeFormat.CODABAR]);
  hints.set(Z.DecodeHintType.TRY_HARDER, true);
  var rd = new Z.MultiFormatReader(); rd.setHints(hints);
  var cv = document.createElement('canvas'), cx = cv.getContext('2d', { willReadFrequently:true });
  return function(fonte){
    var w = fonte.videoWidth || fonte.naturalWidth || fonte.width, h = fonte.videoHeight || fonte.naturalHeight || fonte.height;
    if(!w || !h) return Promise.resolve('');
    var esc2 = Math.min(1, 900 / w); cv.width = Math.round(w * esc2); cv.height = Math.round(h * esc2);
    cx.drawImage(fonte, 0, 0, cv.width, cv.height);
    try{
      var bm = new Z.BinaryBitmap(new Z.HybridBinarizer(new Z.HTMLCanvasElementLuminanceSource(cv)));
      return Promise.resolve(rd.decode(bm).getText());
    }catch(e){ return Promise.resolve(''); }
  };
}
function setHint(t){ $('#scan-hint').textContent = t; }
function bip(){
  try{ if(navigator.vibrate) navigator.vibrate(70); }catch(e){}
  try{
    var A = window.AudioContext || window.webkitAudioContext, a = new A(), o = a.createOscillator(), g = a.createGain();
    o.type = 'square'; o.frequency.value = 1000; g.gain.value = .08; o.connect(g); g.connect(a.destination);
    o.start(); setTimeout(function(){ o.stop(); a.close(); }, 120);
  }catch(e){}
}
function pararCamera(){
  scan.ativo = false; clearTimeout(scan.timer);
  if(scan.stream){ scan.stream.getTracks().forEach(function(t){ t.stop(); }); scan.stream = null; }
  var v = $('#video'); v.pause(); v.srcObject = null;
  scan.lanterna = false; $('#b-torch').classList.remove('on');
}
function fecharScanner(){ pararCamera(); $('#scanner').hidden = true; }
async function abrirScanner(){
  if(scan.ativo) return;
  if(!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia){
    setStatus('warn', 'Este navegador não permite usar a câmera. Use "Tirar foto do código" ou digite o código.'); return;
  }
  $('#scanner').hidden = false; scan.ativo = true; setHint('Abrindo a câmera…');
  try{
    scan.stream = await navigator.mediaDevices.getUserMedia({ video:{ facingMode:{ ideal:'environment' }, width:{ ideal:1280 }, height:{ ideal:720 } }, audio:false });
  }catch(e){
    fecharScanner();
    setStatus('warn', e && e.name === 'NotAllowedError'
      ? 'A câmera está bloqueada. Libere em Configurações do Chrome > Configurações do site > Câmera, ou use "Tirar foto do código".'
      : 'Não consegui abrir a câmera. Use "Tirar foto do código" ou digite o código.');
    return;
  }
  var v = $('#video'); v.srcObject = scan.stream;
  try{ await v.play(); }catch(e){}
  var tr = scan.stream.getVideoTracks()[0], caps = (tr && tr.getCapabilities) ? tr.getCapabilities() : {};
  $('#b-torch').hidden = !caps.torch;
  var ler;
  try{ ler = await criarLeitor(); }
  catch(e){
    fecharScanner();
    setStatus('warn', 'O leitor do navegador não está disponível e o leitor de reserva precisa de internet na primeira vez. Digite o código ou use "Tirar foto do código".');
    return;
  }
  if(!scan.ativo) return;
  setHint('Aponte para o código de barras');
  (async function ciclo(){
    if(!scan.ativo) return;
    try{
      var cod = await ler(v);
      if(cod && scan.ativo){ bip(); fecharScanner(); aoLerCodigo(cod); return; }
    }catch(e){}
    if(scan.ativo) scan.timer = setTimeout(ciclo, 140);
  })();
}
async function alternarLanterna(){
  if(!scan.stream) return;
  var tr = scan.stream.getVideoTracks()[0];
  try{
    scan.lanterna = !scan.lanterna;
    await tr.applyConstraints({ advanced:[{ torch:scan.lanterna }] });
    $('#b-torch').classList.toggle('on', scan.lanterna);
  }catch(e){ scan.lanterna = false; $('#b-torch').classList.remove('on'); }
}
async function lerFoto(file){
  if(!file) return;
  setStatus('busy', 'Lendo a foto…');
  var cod = '';
  try{
    var ler = await criarLeitor(), bmp = await createImageBitmap(file);
    cod = await ler(bmp); if(bmp.close) bmp.close();
  }catch(e){ cod = ''; }
  if(cod) aoLerCodigo(cod);
  else setStatus('warn', 'Não consegui ler o código nesta foto. Tente de mais perto e com boa luz, ou digite o código.');
}

/* ---------- movimentação ---------- */
function acharAtual(f){
  var p = null;
  S.produtos.forEach(function(x){ if(S.sel && x.id === S.sel) p = x; });
  if(!p && f.codigo) p = achar(f.codigo);
  return p;
}
function mover(tipo){
  var f = lerForm();
  if(!f.nome){ setStatus('warn', 'Informe o nome do produto.'); $('#f-nome').focus(); return; }
  var p = acharAtual(f);
  if(!p && tipo === 'saida'){ setStatus('warn', 'Este produto ainda não está no estoque. Registre uma entrada primeiro.'); return; }
  if(tipo === 'saida' && f.qtd > p.qtd){ setStatus('warn', 'Só há ' + p.qtd + ' no estoque. Diminua a quantidade da saída.'); return; }
  var novo = { id:p ? p.id : novoId(f.codigo), codigo:f.codigo, nome:f.nome, marca:f.marca, prateleira:f.prateleira, validade:f.validade, min:f.min,
    qtd:(p ? p.qtd : 0) + (tipo === 'entrada' ? f.qtd : -f.qtd), exemplo:p ? p.exemplo : false };
  putProduto(novo);
  addMov({ ts:Date.now(), tipo:tipo, id_produto:novo.id, nome:novo.nome, qtd:f.qtd, quem:f.quem, exemplo:novo.exemplo });
  limpar(); renderAll();
  setStatus('ok', (tipo === 'entrada' ? 'Entrada' : 'Saída') + ' registrada: ' + novo.nome + ' (' + (tipo === 'entrada' ? '+' : '−') + f.qtd + '). Estoque agora: ' + novo.qtd + '.');
}
function salvarCadastro(){
  var f = lerForm();
  if(!f.nome){ setStatus('warn', 'Informe o nome do produto.'); $('#f-nome').focus(); return; }
  var p = acharAtual(f);
  var novo = { id:p ? p.id : novoId(f.codigo), codigo:f.codigo, nome:f.nome, marca:f.marca, prateleira:f.prateleira, validade:f.validade, min:f.min, qtd:p ? p.qtd : 0, exemplo:p ? p.exemplo : false };
  putProduto(novo); S.sel = novo.id; renderAll();
  setStatus('ok', 'Cadastro salvo: ' + novo.nome + '. Estoque atual: ' + novo.qtd + '.');
}
function excluir(){
  if(!S.sel) return;
  var p = null; S.produtos.forEach(function(x){ if(x.id === S.sel) p = x; });
  delProduto(S.sel); limpar(); renderAll();
  setStatus('ok', 'Produto excluído' + (p ? ': ' + p.nome : '') + '. O histórico foi mantido.');
}

/* ---------- lista de pedido ---------- */
function abrirPedido(){
  var rep = S.produtos.filter(function(p){ return p.qtd <= p.min; }).sort(function(a,b){ return a.qtd - b.qtd || nat(a.nome, b.nome); });
  if(!rep.length) return;
  var linhas = ['Lista de pedido · ' + new Date().toLocaleDateString('pt-BR'), ''];
  rep.forEach(function(p){
    var sug = Math.max(p.min * 2 - p.qtd, 1);
    linhas.push('• ' + p.nome + (p.marca ? ' (' + p.marca + ')' : '') + ': pedir ' + sug + ' un. (estoque atual: ' + p.qtd + ')');
  });
  $('#pedido').value = linhas.join('\n');
  $('#b-copy').textContent = 'Copiar lista';
  $('#sheet').hidden = false;
}
async function copiar(){
  var ta = $('#pedido'), b = $('#b-copy');
  try{ await navigator.clipboard.writeText(ta.value); b.textContent = 'Copiado'; }
  catch(e){ ta.focus(); ta.select(); b.textContent = 'Selecionado: copie manualmente'; }
}

/* ---------- backup ---------- */
function exportar(){
  var d = new Date(), dia = d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
  var blob = new Blob([JSON.stringify({ app:'almoxarifado', versao:1, exportadoEm:d.toISOString(), produtos:S.produtos, movimentos:S.movs }, null, 1)], { type:'application/json' });
  var a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = 'almoxarifado-backup-' + dia + '.json';
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(function(){ URL.revokeObjectURL(a.href); }, 4000);
}
function importar(file){
  if(!file) return;
  var rd = new FileReader();
  rd.onload = function(){
    try{
      var j = JSON.parse(String(rd.result));
      if(!j || j.app !== 'almoxarifado' || !Array.isArray(j.produtos)) throw new Error('formato');
      var n = 0;
      j.produtos.forEach(function(o){ if(o && o.id && o.nome){ putProduto(norm(o)); n++; } });
      var ids = {}; S.movs.forEach(function(m){ ids[m.id] = 1; });
      (j.movimentos || []).forEach(function(m){ if(m && m.id && !ids[m.id]){ S.movs.push(m); } });
      S.movs.sort(function(a, b){ return b.ts - a.ts; }); salvar(); renderAll();
      go('alertas'); alert('Backup importado: ' + pl(n, 'produto', 'produtos') + '.');
    }catch(e){ alert('Esse arquivo não parece um backup do app.'); }
  };
  rd.readAsText(file);
}

/* ---------- exemplos ---------- */
var EX = [
  { id:'ex-1', nome:'Água sanitária 5 L', marca:'Brilhante', prateleira:'A1', qtd:2, min:6, dias:240 },
  { id:'ex-2', nome:'Sacos de lixo 50 L (pacote)', marca:'ProClean', prateleira:'D1', qtd:0, min:8, dias:null },
  { id:'ex-3', nome:'Desengordurante cozinha 750 ml', marca:'LimpMax', prateleira:'B1', qtd:3, min:5, dias:138 },
  { id:'ex-4', nome:'Limpa-pisos lavanda 2 L', marca:'Brilhante', prateleira:'A1', qtd:4, min:6, dias:310 },
  { id:'ex-5', nome:'Luvas de borracha tam. M', marca:'ProClean', prateleira:'D1', qtd:5, min:8, dias:null },
  { id:'ex-6', nome:'Multiuso 500 ml', marca:'LimpMax', prateleira:'A2', qtd:18, min:6, dias:42 },
  { id:'ex-7', nome:'Cera para piso 750 ml', marca:'Brilhante', prateleira:'A2', qtd:12, min:5, dias:400 },
  { id:'ex-8', nome:'Papel toalha (fardo)', marca:'ProClean', prateleira:'C1', qtd:30, min:10, dias:null }
];
var MV = [ [0,'saida','ex-1',2,'Marta',2.5], [0,'entrada','ex-8',24,'Luis',3.5], [1,'saida','ex-5',4,'Marta',20], [2,'entrada','ex-3',12,'Carlos',44], [2,'saida','ex-4',3,'Ana',46], [3,'saida','ex-6',6,'Luis',70], [4,'saida','ex-2',5,'Ana',93], [5,'entrada','ex-7',12,'Carlos',118] ];
function carregarExemplos(){
  EX.forEach(function(e){
    var v = '';
    if(e.dias !== null){ var d = new Date(hoje().getTime() + e.dias * 86400000); v = d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0'); }
    putProduto({ id:e.id, codigo:'', nome:e.nome, marca:e.marca, prateleira:e.prateleira, validade:v, qtd:e.qtd, min:e.min, exemplo:true });
  });
  MV.forEach(function(m){
    var nome = ''; EX.forEach(function(x){ if(x.id === m[2]) nome = x.nome; });
    addMov({ ts:Date.now() - m[5] * 3600000, tipo:m[1], id_produto:m[2], nome:nome, qtd:m[3], quem:m[4], exemplo:true });
  });
  renderAll();
}
function apagarExemplos(){
  S.produtos = S.produtos.filter(function(p){ return !p.exemplo; });
  S.movs = S.movs.filter(function(m){ return !m.exemplo; });
  salvar(); renderAll();
}

/* ---------- eventos ---------- */
document.addEventListener('click', function(ev){
  var t = ev.target.closest('[data-tab]');
  if(t){ go(t.dataset.tab); return; }
  var b = ev.target.closest('[data-a]');
  if(!b) return;
  var a = b.dataset.a;
  if(a === 'go-escanear') go('escanear');
  else if(a === 'camera') abrirScanner();
  else if(a === 'fechar-scan') fecharScanner();
  else if(a === 'lanterna') alternarLanterna();
  else if(a === 'exemplos') carregarExemplos();
  else if(a === 'apagar-exemplos') apagarExemplos();
  else if(a === 'pedido') abrirPedido();
  else if(a === 'fechar') $('#sheet').hidden = true;
  else if(a === 'copiar') copiar();
  else if(a === 'abrir') abrirProduto(b.dataset.id);
  else if(a === 'chip'){ S.prat = b.dataset.v; renderEstantes(); }
  else if(a === 'buscar') buscarCodigo();
  else if(a === 'entrada') mover('entrada');
  else if(a === 'saida') mover('saida');
  else if(a === 'salvar') salvarCadastro();
  else if(a === 'limpar'){ limpar(); setStatus('', ''); }
  else if(a === 'mais'){ var q = $('#f-qtd'); q.value = (parseInt(q.value, 10) || 0) + 1; }
  else if(a === 'menos'){ var q2 = $('#f-qtd'); q2.value = Math.max(1, (parseInt(q2.value, 10) || 2) - 1); }
  else if(a === 'exportar') exportar();
  else if(a === 'importar') $('#arquivo-backup').click();
  else if(a === 'instalar' && instalar){ instalar.prompt(); instalar.userChoice.then(function(){ instalar = null; renderAlertas(); }); }
  else if(a === 'excluir'){
    if(b.dataset.armed){ delete b.dataset.armed; b.textContent = 'Excluir produto'; excluir(); }
    else { b.dataset.armed = '1'; b.textContent = 'Toque de novo para excluir'; setTimeout(function(){ delete b.dataset.armed; b.textContent = 'Excluir produto'; }, 4000); }
  }
});
$('#sheet').addEventListener('click', function(ev){ if(ev.target === ev.currentTarget) ev.currentTarget.hidden = true; });
$('#busca').addEventListener('input', function(ev){ S.busca = ev.target.value; renderEstantes(); });
$('#f-val').addEventListener('input', updValPill);
$('#f-codigo').addEventListener('keydown', function(ev){ if(ev.key === 'Enter'){ ev.preventDefault(); buscarCodigo(); } });
$('#f-quem').addEventListener('input', function(ev){ try{ localStorage.setItem(LS + '-quem', ev.target.value); }catch(e){} });
$('#foto').addEventListener('change', function(ev){ var f = ev.target.files && ev.target.files[0]; ev.target.value = ''; lerFoto(f); });
$('#arquivo-backup').addEventListener('change', function(ev){ var f = ev.target.files && ev.target.files[0]; ev.target.value = ''; importar(f); });
document.addEventListener('visibilitychange', function(){ if(document.hidden && scan.ativo) fecharScanner(); });
window.addEventListener('online', setSync);
window.addEventListener('offline', setSync);
window.addEventListener('beforeinstallprompt', function(ev){ ev.preventDefault(); instalar = ev; renderAlertas(); });
window.addEventListener('appinstalled', function(){ instalar = null; renderAlertas(); });

/* ---------- início ---------- */
$('#logo').innerHTML = ico('warehouse', 24);
$('#ico-search').innerHTML = ico('search', 20);
$('#ico-cam').innerHTML = '<svg class="i" width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3"/><path d="M8 9v6M11 9v6M14 9v6M17 9v6"/></svg>';
$('#ico-in').innerHTML = ico('plus', 28);
$('#ico-out').innerHTML = ico('minus', 28);
$('#ico-up').innerHTML = ico('up', 18);
$('#ico-down').innerHTML = ico('down', 18);
$('#ico-x').innerHTML = ico('x', 24);
$('#b-torch').innerHTML = ico('bolt', 22);
$$('[data-i]').forEach(function(s){ s.innerHTML = ico(s.dataset.i, 22); });
try{ $('#f-quem').value = localStorage.getItem(LS + '-quem') || ''; }catch(e){}
carregar();
renderAll();
try{ if(navigator.storage && navigator.storage.persist) navigator.storage.persist(); }catch(e){}
if('serviceWorker' in navigator){ window.addEventListener('load', function(){ navigator.serviceWorker.register('sw.js').catch(function(){}); }); }
})();
